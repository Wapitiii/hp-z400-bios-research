
USB Key Utility by TTAV134
===============================

"USB boot creator.exe" - Windows-based utility to locally partition, format and copy necessary files to
a USB flash media device through the Windows environment.


HOW TO USE:
  
     1. Close all other applications before launching USB Key Utility.

     2. Obtain a formatted USB media key and place it in the USB port.     
          
     3. Double-click on the file "USB boot creator.EXE" and follow the instructions to complete 
        the preparation of the USB flash media device.      
 	
     4. Copy your ROM bios file (68xxx.bin) on the USB key (xxx are depending of your machine)
     
     5. Place the newly created USB flash media device into the PC to be updated
        and cycle system power to boot from the USB flash media device.

     6. Follow the on-screen instructions.

WARNING:  DO NOT TURN OFF POWER OR ATTEMPT TO REBOOT THE COMPUTER DURING THE UPDATE PROCESS!!!


